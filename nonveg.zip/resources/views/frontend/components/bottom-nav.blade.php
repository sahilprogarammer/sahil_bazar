<style>
    /* =====================================================
   DEMO CONTENT
===================================================== */

    .page-content {
        width: 100%;
        max-width: 430px;
        margin: auto;
        padding: 25px 18px;
    }

    .demo-card {
        background: #ffffff;
        border-radius: 20px;
        padding: 25px;

        box-shadow:
            0 5px 20px rgba(0, 0, 0, 0.05);
    }

    .demo-card h1 {
        font-size: 24px;
        margin-bottom: 10px;
    }

    .demo-card p {
        font-size: 14px;
        color: #777;
        line-height: 1.6;
    }


    /* =====================================================
   BOTTOM NAVIGATION
===================================================== */

    .bottom-nav {
        position: fixed;

        left: 50%;
        bottom: 0;

        transform: translateX(-50%);

        width: 100%;
        max-width: 430px;

        height: 70px;

        background: #ffffff;

        border-top: 1px solid #e8ebe5;

        display: flex;
        align-items: center;
        justify-content: space-around;

        z-index: 9000;

        padding:
            5px 4px calc(5px + env(safe-area-inset-bottom));

        box-shadow:
            0 -4px 20px rgba(0, 0, 0, 0.06);
    }


    /* =====================================================
   NAV ITEM
===================================================== */

    .nav-item {
        flex: 1;

        height: 58px;

        display: flex;
        flex-direction: column;

        align-items: center;
        justify-content: center;

        gap: 4px;

        border: 0;
        background: transparent;

        text-decoration: none;

        color: #8b918a;

        cursor: pointer;

        font-family: inherit;

        -webkit-tap-highlight-color: transparent;

        transition:
            color 0.2s ease,
            transform 0.2s ease;
    }

    .nav-item:active {
        transform: scale(0.92);
    }


    /* =====================================================
   NAV ICON
===================================================== */

    .nav-icon {
        width: 25px;
        height: 25px;

        display: flex;
        align-items: center;
        justify-content: center;

        font-size: 21px;
        line-height: 1;
    }


    /* =====================================================
   NAV LABEL
===================================================== */

    .nav-label {
        font-size: 10px;
        font-weight: 600;
        line-height: 1;
    }


    /* =====================================================
   ACTIVE
===================================================== */

    .nav-item.active {
        color: #146b2f;
    }

    .nav-item.active .nav-icon {
        transform: translateY(-1px);
    }


    /* =====================================================
   CART
===================================================== */

    .cart-wrapper {
        position: relative;

        width: 28px;
        height: 27px;

        display: flex;
        align-items: center;
        justify-content: center;
    }

    .cart-count {
        position: absolute;

        top: -5px;
        right: -7px;

        min-width: 17px;
        height: 17px;

        padding: 0 4px;

        border-radius: 50px;

        background: #f47c20;
        color: #ffffff;

        font-size: 9px;
        font-weight: 700;

        display: none;

        align-items: center;
        justify-content: center;

        border: 2px solid #ffffff;
    }


    /* =====================================================
   MENU OVERLAY
===================================================== */

    .menu-overlay {
        position: fixed;

        inset: 0;

        background:
            rgba(0, 0, 0, 0.45);

        backdrop-filter:
            blur(4px);

        -webkit-backdrop-filter:
            blur(4px);

        z-index: 9998;

        opacity: 0;
        visibility: hidden;

        pointer-events: none;

        transition:
            opacity 0.35s cubic-bezier(0.22, 1, 0.36, 1),

            visibility 0s linear 0.35s;
    }

    .menu-overlay.active {
        opacity: 1;

        visibility: visible;

        pointer-events: auto;

        transition:
            opacity 0.35s cubic-bezier(0.22, 1, 0.36, 1),

            visibility 0s linear 0s;
    }


    /* =====================================================
   LEFT SIDE MENU
===================================================== */

    .menu-sheet {
        position: fixed;

        top: 0;
        left: 0;
        bottom: 0;

        width: 75%;
        max-width: 360px;

        background: #ffffff;

        z-index: 9999;

        /*
       Start outside screen
    */

        transform:
            translate3d(-105%, 0, 0);

        /*
       Hardware acceleration
    */

        will-change: transform;

        transition:
            transform 0.58s cubic-bezier(0.22, 1, 0.36, 1);

        padding:
            calc(18px + env(safe-area-inset-top)) 18px calc(18px + env(safe-area-inset-bottom));

        box-shadow:
            10px 0 40px rgba(0, 0, 0, 0.16);

        overflow-y: auto;

        -webkit-overflow-scrolling:
            touch;

        overscroll-behavior:
            contain;
    }


    /* =====================================================
   OPEN STATE
===================================================== */

    .menu-sheet.active {
        transform:
            translate3d(0, 0, 0);
    }


    /* =====================================================
   MENU HEADER
===================================================== */

    .menu-sheet-header {
        display: flex;

        align-items: center;
        justify-content: space-between;

        margin-bottom: 20px;

        opacity: 0;

        transform:
            translate3d(-15px, 0, 0);

        transition:
            opacity 0.28s ease,
            transform 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    }


    /* =====================================================
   HEADER OPEN ANIMATION
===================================================== */

    .menu-sheet.active .menu-sheet-header {
        opacity: 1;

        transform:
            translate3d(0, 0, 0);

        transition-delay:
            0.08s;
    }


    /* =====================================================
   MENU TITLE
===================================================== */

    .menu-sheet-title {
        font-size: 22px;

        font-weight: 800;

        color: #172018;
    }


    /* =====================================================
   MENU SUBTITLE
===================================================== */

    .menu-sheet-subtitle {
        margin-top: 5px;

        font-size: 12px;

        color: #858b84;
    }


    /* =====================================================
   CLOSE BUTTON
===================================================== */

    .menu-close-btn {
        width: 38px;
        height: 38px;

        border: 0;

        border-radius: 50%;

        background: #f1f3ef;

        color: #172018;

        font-size: 25px;

        display: flex;

        align-items: center;
        justify-content: center;

        cursor: pointer;

        line-height: 1;

        -webkit-tap-highlight-color:
            transparent;

        transition:
            transform 0.2s ease,
            background 0.2s ease;
    }

    .menu-close-btn:active {
        transform:
            scale(0.88);

        background:
            #e8ebe5;
    }


    /* =====================================================
   BRAND
===================================================== */

    .menu-brand {
        display: flex;

        align-items: center;

        gap: 12px;

        padding: 15px;

        margin-bottom: 9px;

        background: #f6f9f4;

        border-radius: 18px;

        opacity: 0;

        transform:
            translate3d(-15px, 0, 0);

        transition:
            opacity 0.28s ease,
            transform 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    }


    /* =====================================================
   BRAND OPEN ANIMATION
===================================================== */

    .menu-sheet.active .menu-brand {
        opacity: 1;

        transform:
            translate3d(0, 0, 0);

        transition-delay:
            0.12s;
    }


    /* =====================================================
   BRAND ICON
===================================================== */

    .menu-brand-icon {
        width: 48px;
        height: 48px;

        border-radius: 14px;

        background: #e4f1e1;

        display: flex;

        align-items: center;
        justify-content: center;

        font-size: 24px;
    }


    /* =====================================================
   BRAND NAME
===================================================== */

    .menu-brand-name {
        font-size: 15px;

        font-weight: 800;

        color: #172018;
    }


    /* =====================================================
   BRAND TEXT
===================================================== */

    .menu-brand-text {
        margin-top: 3px;

        font-size: 11px;

        color: #858b84;
    }


    /* =====================================================
   MENU LIST
===================================================== */

    .menu-list {
        display: flex;

        flex-direction: column;

        gap: 4px;
    }


    /* =====================================================
   MENU ITEM
===================================================== */

    .menu-list-item {
        width: 100%;

        min-height: 68px;

        display: flex;

        align-items: center;

        text-align: left;

        border: 0;

        /* background: #f8f9f6; */

        border-radius: 17px;
        text-decoration: none;

        color: #172018;

        cursor: pointer;

        font-family: inherit;

        -webkit-tap-highlight-color:
            transparent;

        /*
       Initial animation state
    */

        opacity: 0;

        transform:
            translate3d(-18px, 0, 0);

        transition:
            opacity 0.28s ease,
            transform 0.38s cubic-bezier(0.22, 1, 0.36, 1),
            background 0.18s ease;
    }


    /* =====================================================
   MENU ITEMS OPEN ANIMATION
===================================================== */

    .menu-sheet.active .menu-list-item {
        opacity: 1;

        transform:
            translate3d(0, 0, 0);
    }


    /* =====================================================
   STAGGER ANIMATION
===================================================== */

    .menu-sheet.active .menu-list-item:nth-child(1) {
        transition-delay:
            0.15s;
    }

    .menu-sheet.active .menu-list-item:nth-child(2) {
        transition-delay:
            0.19s;
    }

    .menu-sheet.active .menu-list-item:nth-child(3) {
        transition-delay:
            0.23s;
    }

    .menu-sheet.active .menu-list-item:nth-child(4) {
        transition-delay:
            0.27s;
    }

    .menu-sheet.active .menu-list-item:nth-child(5) {
        transition-delay:
            0.31s;
    }

    .menu-sheet.active .menu-list-item:nth-child(6) {
        transition-delay:
            0.35s;
    }


    /* =====================================================
   MENU ITEM PRESS
===================================================== */

    .menu-list-item:active {
        transform:
            scale(0.97);

        background:
            #eef1eb;
    }


    /* =====================================================
   MENU ICON
===================================================== */

    .menu-item-icon {
        width: 44px;
        height: 44px;

        flex: 0 0 44px;

        border-radius: 14px;

        display: flex;

        align-items: center;
        justify-content: center;

        font-size: 19px;
    }


    /* =====================================================
   PROFILE ICON
===================================================== */

    .profile-icon {
        background:
            #e8f4e6;
    }


    /* =====================================================
   ORDER ICON
===================================================== */

    .order-icon {
        background:
            #fff0dd;
    }


    /* =====================================================
   ADDRESS ICON
===================================================== */

    .address-icon {
        background:
            #e9f3ff;
    }


    /* =====================================================
   HELP ICON
===================================================== */

    .help-icon {
        background:
            #f0ebff;

        color:
            #6644d9;

        font-weight:
            800;

        font-size:
            18px;
    }


    /* =====================================================
   LOGOUT ICON
===================================================== */

    .logout-icon {
        background:
            #ffeded;

        color:
            #d93333;
    }


    /* =====================================================
   MENU CONTENT
===================================================== */

    .menu-item-content {
        flex: 1;

        min-width: 0;

        margin-left: 12px;
    }


    /* =====================================================
   MENU ITEM TITLE
===================================================== */

    .menu-item-title {
        font-size: 14px;

        font-weight: 700;

        color: #172018;
    }


    /* =====================================================
   MENU ITEM SUBTITLE
===================================================== */

    .menu-item-subtitle {
        margin-top: 4px;

        font-size: 11px;

        color: #858b84;

        white-space: nowrap;

        overflow: hidden;

        text-overflow: ellipsis;
    }


    /* =====================================================
   ARROW
===================================================== */

    .menu-arrow {
        font-size: 25px;

        color: #9ba19a;

        line-height: 1;

        margin-left: 8px;

        transition:
            transform 0.2s ease;
    }


    /* =====================================================
   ARROW HOVER / ACTIVE
===================================================== */

    .menu-list-item:active .menu-arrow {
        transform:
            translateX(3px);
    }


    /* =====================================================
   LOGOUT
===================================================== */

    .menu-logout {
        color:
            #d93333;
    }

    .menu-logout .menu-item-title {
        color:
            #d93333;
    }


    /* =====================================================
   LOGOUT FORM
===================================================== */

    .menu-logout-form {
        margin: 0;

        padding: 0;
    }


    /* =====================================================
   FOOTER
===================================================== */

    .menu-sheet-footer {
        display: flex;

        justify-content: center;
        align-items: center;

        gap: 6px;

        padding:
            25px 0 5px;

        font-size: 10px;

        color: #9ca29b;

        opacity: 0;

        transform:
            translate3d(-10px, 0, 0);

        transition:
            opacity 0.28s ease,
            transform 0.38s cubic-bezier(0.22, 1, 0.36, 1);
    }


    /* =====================================================
   FOOTER OPEN ANIMATION
===================================================== */

    .menu-sheet.active .menu-sheet-footer {
        opacity: 1;

        transform:
            translate3d(0, 0, 0);

        transition-delay:
            0.38s;
    }


    /* =====================================================
   BODY WHEN MENU OPEN
===================================================== */

    body.menu-open {
        overflow: hidden;

        /*
       Prevent background movement
    */

        touch-action:
            none;
    }


    /* =====================================================
   MOBILE ONLY
===================================================== */

    /* @media (min-width: 768px) {

        .bottom-nav {
            display: none;
        }

        .menu-sheet,
        .menu-overlay {
            display: none !important;
        }

        body {
            padding-bottom: 0;
        }
    } */


    /* =====================================================
   REDUCED MOTION
===================================================== */

    @media (prefers-reduced-motion: reduce) {

        .menu-sheet,
        .menu-overlay,
        .menu-sheet-header,
        .menu-brand,
        .menu-list-item,
        .menu-sheet-footer,
        .menu-arrow {
            transition: none !important;
        }
    }
</style>


<!-- =====================================================
     BOTTOM NAVIGATION
===================================================== -->

<nav class="bottom-nav">


    <!-- HOME -->

    <a href="{{ url('/') }}"
        class="nav-item
        {{ request()->is('/') || request()->is('Home') ? 'active' : '' }}">

        <span class="nav-icon">
            ⌂
        </span>

        <span class="nav-label">
            Home
        </span>

    </a>


    <!-- EXPLORE -->

    <a href="{{ route('explore') }}"
        class="nav-item
        {{ request()->routeIs('explore') ? 'active' : '' }}">

        <span class="nav-icon">
            ⌕
        </span>

        <span class="nav-label">
            Explore
        </span>

    </a>


    <!-- CART -->

    <a href="{{ route('cart') }}"
        class="nav-item
        {{ request()->routeIs('cart') ? 'active' : '' }}">

        <span class="cart-wrapper">

            <span class="nav-icon">
                🛒
            </span>

            <span
                class="cart-count"
                id="cartCount">
            </span>

        </span>

        <span class="nav-label">
            Cart
        </span>

    </a>


    <!-- ORDERS -->

    <!-- <a href="{{ route('my-orders') }}"
        class="nav-item
        {{ request()->routeIs('my-orders') ? 'active' : '' }}">

        <span class="nav-icon">
            📦
        </span>

        <span class="nav-label">
            Orders
        </span>

    </a> -->


    <!-- ACCOUNT -->

    <a href="{{ Auth::check()
        ? route('profile')
        : 'javascript:void(0)' }}"
        class="nav-item
        {{ request()->routeIs('profile') ? 'active' : '' }}"

        @if(!Auth::check())
        onclick="openLoginPopup()"
        @endif>

        <span class="nav-icon">
            👤
        </span>

        <span class="nav-label">
            Account
        </span>

    </a>


    <!-- MENU -->

    <button
        type="button"
        class="nav-item menu-nav-btn"
        onclick="openMenuSheet()">

        <span class="nav-icon">
            ☰
        </span>

        <span class="nav-label">
            Menu
        </span>

    </button>

</nav>



<!-- =====================================================
     MENU OVERLAY
===================================================== -->

<div
    class="menu-overlay"
    id="menuOverlay"
    onclick="closeMenuSheet()">
</div>



<!-- =====================================================
     LEFT SIDE MENU
===================================================== -->

<div
    class="menu-sheet"
    id="menuSheet">


    <!-- HEADER -->

    <div class="menu-sheet-header">

        <div>

            <div class="menu-sheet-title">
                Menu
            </div>

            <div class="menu-sheet-subtitle">
                Manage your Nonveg Mart account
            </div>

        </div>


        <button
            type="button"
            class="menu-close-btn"
            onclick="closeMenuSheet()">

            ×

        </button>

    </div>



    <!-- BRAND -->

    <div class="menu-brand">

        <div class="menu-brand-icon">
            🥩
        </div>

        <div>

            <div class="menu-brand-name">
                Nonveg Mart
            </div>

            <div class="menu-brand-text">
                Fresh. Fast. Local.
            </div>

        </div>

    </div>



    <!-- MENU ITEMS -->

    <div class="menu-list">


        <!-- PROFILE -->

        <a
            href="{{ Auth::check()
                ? route('profile')
                : 'javascript:void(0)' }}"

            class="menu-list-item"

            @if(!Auth::check())
            onclick="
                    closeMenuSheet();
                    openLoginPopup();
                "
            @endif>

            <div
                class="menu-item-icon profile-icon">

                👤

            </div>


            <div class="menu-item-content">

                <div class="menu-item-title">
                    My Profile
                </div>

                <div class="menu-item-subtitle">
                    Manage your account
                </div>

            </div>


            <div class="menu-arrow">
                ›
            </div>

        </a>



        <!-- ORDERS -->

        <a
            href="{{ route('my-orders') }}"
            class="menu-list-item">

            <div
                class="menu-item-icon order-icon">

                📦

            </div>


            <div class="menu-item-content">

                <div class="menu-item-title">
                    My Orders
                </div>

                <div class="menu-item-subtitle">
                    View your order history
                </div>

            </div>


            <div class="menu-arrow">
                ›
            </div>

        </a>



        <!-- ADDRESSES -->

        <a
            href="{{ route('about-us') }}"
            class="menu-list-item">

            <div
                class="menu-item-icon address-icon">

                📍

            </div>


            <div class="menu-item-content">

                <div class="menu-item-title">
                    About Us
                </div>

                <div class="menu-item-subtitle">
                    Learn more about Nonveg Mart
                </div>

            </div>


            <div class="menu-arrow">
                ›
            </div>

        </a>



        <!-- HELP -->

        <a
            href="javascript:void(0)"
            class="menu-list-item">

            <div
                class="menu-item-icon help-icon">

                ?

            </div>


            <div class="menu-item-content">

                <div class="menu-item-title">
                    Help & Support
                </div>

                <div class="menu-item-subtitle">
                    Get help with your order
                </div>

            </div>


            <div class="menu-arrow">
                ›
            </div>

        </a>



        @auth

        <!-- LOGOUT -->

        <form
            method="POST"
            action="{{ route('logout') }}"
            class="menu-logout-form">

            @csrf

            <button
                type="submit"
                class="menu-list-item menu-logout">

                <div
                    class="menu-item-icon logout-icon">

                    ↪

                </div>


                <div class="menu-item-content">

                    <div class="menu-item-title">
                        Logout
                    </div>

                    <div class="menu-item-subtitle">
                        Sign out from your account
                    </div>

                </div>


                <div class="menu-arrow">
                    ›
                </div>

            </button>

        </form>

        @endauth


    </div>



    <!-- FOOTER -->

    <div class="menu-sheet-footer">

        <span>
            Nonveg Mart
        </span>

        <span>
            •
        </span>

        <span>
            Fresh. Fast. Local.
        </span>

    </div>

</div>



<script>
    /* =====================================================
       OPEN MENU
    ===================================================== */

    function openMenuSheet() {

        const overlay =
            document.getElementById(
                'menuOverlay'
            );

        const sheet =
            document.getElementById(
                'menuSheet'
            );


        if (!overlay || !sheet) {
            return;
        }


        overlay.classList.add(
            'active'
        );

        sheet.classList.add(
            'active'
        );

        document.body.classList.add(
            'menu-open'
        );

    }



    /* =====================================================
       CLOSE MENU
    ===================================================== */

    function closeMenuSheet() {

        const overlay =
            document.getElementById(
                'menuOverlay'
            );

        const sheet =
            document.getElementById(
                'menuSheet'
            );


        if (!overlay || !sheet) {
            return;
        }


        overlay.classList.remove(
            'active'
        );

        sheet.classList.remove(
            'active'
        );

        document.body.classList.remove(
            'menu-open'
        );

    }



    /* =====================================================
       SWIPE LEFT TO CLOSE
    ===================================================== */

    const menuSheet =
        document.getElementById(
            'menuSheet'
        );


    let touchStartX = 0;

    let touchEndX = 0;


    if (menuSheet) {

        menuSheet.addEventListener(
            'touchstart',
            function(event) {

                touchStartX =
                    event.touches[0].clientX;

            }, {
                passive: true
            }
        );


        menuSheet.addEventListener(
            'touchend',
            function(event) {

                touchEndX =
                    event.changedTouches[0].clientX;


                const difference =
                    touchStartX -
                    touchEndX;


                /*
                 * Swipe from right to left
                 * to close drawer
                 */

                if (difference > 80) {

                    closeMenuSheet();

                }

            }, {
                passive: true
            }
        );

    }



    /* =====================================================
       ESC TO CLOSE
    ===================================================== */

    document.addEventListener(
        'keydown',
        function(event) {

            if (
                event.key === 'Escape'
            ) {

                closeMenuSheet();

            }

        }
    );



    /* =====================================================
       CART COUNT
    ===================================================== */

    function updateCartCount() {

        let cart = [];


        try {

            cart =
                JSON.parse(
                    localStorage.getItem(
                        'cart'
                    )
                ) || [];

        } catch (error) {

            console.error(
                'Cart localStorage error:',
                error
            );

            cart = [];

        }


        const count =
            cart.length;


        const element =
            document.getElementById(
                'cartCount'
            );


        if (!element) {
            return;
        }


        /*
         * EMPTY
         */

        if (count === 0) {

            element.textContent = '';

            element.style.display =
                'none';

        }


        /*
         * HAS ITEMS
         */
        else {

            element.textContent =
                count;

            element.style.display =
                'flex';

        }

    }



    /* =====================================================
       INITIAL CART COUNT
    ===================================================== */

    document.addEventListener(
        'DOMContentLoaded',
        function() {

            updateCartCount();

        }
    );



    /* =====================================================
       UPDATE CART WHEN LOCAL STORAGE CHANGES
    ===================================================== */

    window.addEventListener(
        'storage',
        function(event) {

            if (
                event.key === 'cart'
            ) {

                updateCartCount();

            }

        }
    );
</script>