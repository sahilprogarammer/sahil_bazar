<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Address;
use App\Models\Category;
use App\Models\DeliveryCharge;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    public function home()
    {
        $categories = Category::where('status', 'active')
            ->with([
                'subcategories' => function ($query) {
                    $query->where('status', 'active');
                }
            ])
            ->get();

        // return $categories;
        $popularProducts = Product::where('status', 'active')->where('is_popular', 1)->get();

        // return $popularProducts;

        $defaultAddress = null;

        if (Auth::check()) {
            $defaultAddress = Address::where('user_id', Auth::id())
                ->where('is_default', 1)
                ->first();
        }

        // return $defaultAddress;

        return view('frontend.pages.home', compact('categories', 'popularProducts', 'defaultAddress'));
    }

    public function category(Category $category)
    {
        $category->load([
            'subcategories' => function ($query) {
                $query->where('status', 'active');
            }
        ]);

        return view('frontend.pages.categories', compact('category'));
    }

    public function subcategory(Category $category, Subcategory $subcategory)
    {
        if (
            $category->status !== 'active' ||
            $subcategory->status !== 'active' ||
            $subcategory->category_id != $category->id
        ) {
            abort(404);
        }

        $products = $subcategory->products()
            ->where('status', 'active')
            ->paginate(12);

        // return $products;

        // return [$category,$subcategory,$products];

        return view(
            'frontend.pages.products',
            compact('category', 'subcategory', 'products')
        );
    }

    public function cart()
    {
        $defaultAddress = null;

        if (Auth::check()) {
            $user_id = Auth::user()->id;
            $defaultAddress = Address::where('user_id', $user_id)
                ->where('is_default', 1)
                ->first();
        }

        $deliveryCharges = DeliveryCharge::where('is_active', 1)
            ->orderBy('min_distance')
            ->orderBy('min_order_amount')
            ->get();

        // return $defaultAddress;
        return view('frontend.pages.cart', compact('defaultAddress', 'deliveryCharges'));
    }


    // public function orderSubmit(Request $request)
    // {
    //     dd([
    //     'METHOD' => $request->method(),
    //     'DATA' => $request->all(),
    //     'USER' => Auth::id(),
    //     'CART' => session()->get('cart', []),
    // ]);
    // }

    public function orderSubmit(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Please login before placing order.',
            ], 401);
        }


        $request->validate([
            'address_id' => 'required|integer|exists:addresses,id',

            'cart' => 'required|string',
        ]);

        $cart = json_decode($request->cart, true);


        if (!is_array($cart) || empty($cart)) {

            return response()->json([
                'success' => false,
                'message' => 'Your cart is empty.',
            ], 422);
        }


        $address = Address::where('id', $request->address_id)
            ->where('user_id', $user->id)
            ->first();

        if (!$address) {

            return response()->json([
                'success' => false,
                'message' => 'Invalid delivery address.',
            ], 422);
        }


        $subtotal = 0;

        foreach ($cart as $item) {

            $subtotal += (float) ($item['total_price'] ?? 0);
        }

        $subtotal = round($subtotal, 2);

        $discount = 0;

        $deliveryCharge = 0;

        $tax = 0;

        $totalAmount =
            $subtotal
            - $discount
            + $deliveryCharge
            + $tax;

        $totalAmount = round($totalAmount, 2);


        DB::beginTransaction();

        try {


            $orderNumber =
                'NB'
                . strtoupper(Str::random(4));


            $order = Order::create([

                'user_id' => $user->id,

                'order_number' => $orderNumber,

                'address_id' => $address->id,

                'subtotal' => $subtotal,

                'discount' => $discount,

                'delivery_charge' => $deliveryCharge,

                'tax' => $tax,

                'total_amount' => $totalAmount,

                'payment_method' => $request->payment_method,

                'payment_status' => 0,

                'order_status' => 'pending',

                'notes' => $request->notes ?? null,

                'placed_at' => now(),
            ]);


            foreach ($cart as $item) {

                OrderItem::create([

                    'order_id' => $order->id,

                    'product_id' => $item['product_id'] ?? null,

                    'product_name' => $item['name'] ?? '',

                    'quantity' => $item['quantity'] ?? 0,

                    'unit' => $item['unit'] ?? null,

                    'price' => $item['price'] ?? 0,

                    'discount_price' => $item['discount_price'] ?? 0,

                    'selling_price' => $item['selling_price'] ?? 0,

                    'total_price' => $item['total_price'] ?? 0,
                ]);
            }


            DB::commit();

            session()->put('checkout_order_id', $order->id);

            return response()->json([

                'success' => true,

                'message' => 'Order placed successfully.',

                'order_id' => $order->id,

                'order_number' => $order->order_number,

                'total_amount' => $order->total_amount,

                'redirect' => route('check-out'),
            ]);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([

                'success' => false,

                'message' => 'Unable to place order.',

                'error' => $e->getMessage(),

            ], 500);
        }
    }

    public function profile()
    {
        $user = Auth::user();
        // return $user;
        $orderCount = Order::where('user_id', $user->id)->count();
        $addressCount = Address::where('user_id', $user->id)->count();
        // return [$orderCount, $addressCount];
        return view('frontend.pages.profile', compact('user', 'orderCount', 'addressCount'));
    }


    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Please login first.'
            ], 401);
        }

        /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

        $request->validate([
            'name' => 'required|string|max:100',

            'email' => [
                'nullable',
                'email',
                'max:150',
                'unique:users,email,' . $user->id,
            ],

            'profile_image' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:2048',
            ],
        ]);


        /*
    |--------------------------------------------------------------------------
    | Update Data
    |--------------------------------------------------------------------------
    */

        $data = [
            'name' => $request->name,
            'email' => $request->email,
        ];


        /*
    |--------------------------------------------------------------------------
    | Profile Image
    |--------------------------------------------------------------------------
    */

        if ($request->hasFile('profile_image')) {

            $file = $request->file('profile_image');

            $folder = public_path('profiles');

            // Create folder if not exists
            if (!File::exists($folder)) {
                File::makeDirectory(
                    $folder,
                    0755,
                    true
                );
            }


            /*
        |--------------------------------------------------------------------------
        | Delete Old Image
        |--------------------------------------------------------------------------
        */

            if (
                !empty($user->profile_image) &&
                File::exists(
                    $folder . '/' . $user->profile_image
                )
            ) {
                File::delete(
                    $folder . '/' . $user->profile_image
                );
            }


            /*
        |--------------------------------------------------------------------------
        | New Image
        |--------------------------------------------------------------------------
        */

            $filename =
                time() . '_' .
                uniqid() . '.' .
                $file->getClientOriginalExtension();


            $file->move(
                $folder,
                $filename
            );


            // Only change image when new image is selected
            $data['profile_image'] = $filename;
        }


        /*
    |--------------------------------------------------------------------------
    | Update User
    |--------------------------------------------------------------------------
    */

        User::where('id', $user->id)->update($data);


        /*
    |--------------------------------------------------------------------------
    | Get Updated User
    |--------------------------------------------------------------------------
    */

        $user = User::find($user->id);


        /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

        return response()->json([

            'success' => true,

            'message' => 'Profile updated successfully.',

            'user' => [

                'id' => $user->id,

                'name' => $user->name,

                'email' => $user->email,

                'mobile' => $user->mobile,

                'profile_image' => $user->profile_image
                    ? asset(
                        'profiles/' .
                            $user->profile_image
                    )
                    : null,
            ],

        ]);
    }

    public function myOrders()
    {
        $user = Auth::user();

        if (!$user) {
            return redirect()->route('home');
        }

        $orders = Order::with('orderItems')
            ->where('user_id', $user->id)
            ->latest()
            ->get();

        // return $orders;

        return view('frontend.pages.myorder', compact('orders'));
    }



    public function checkout()
    {
        // return $orderId = session('checkout_order_id');
        return view('frontend.pages.checkout');
    }

    public function explore()
    {
        $subcategories = Subcategory::with('category')
            ->where('status', 1)
            ->orderBy('name', 'asc')
            ->get();
        // return $subcategories;
        return view('frontend.pages.explore', compact('subcategories'));
    }

    public function location()
    {
        return view('frontend/location');
    }

    public function aboutUs()
    {
        return view('frontend.pages.about-us');
    }

    public function helpSupport()
    {
        return view('frontend.pages.help-support');
    }
}
