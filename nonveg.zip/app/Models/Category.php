<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $guarded;
    use HasFactory;

    protected $table = 'categories';

    public function subcategories()
    {
        return $this->hasMany(Subcategory::class, 'category_id');
    }
}
