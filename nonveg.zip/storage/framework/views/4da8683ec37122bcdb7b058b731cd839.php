

<?php $__env->startSection('title', 'Nonveg Bazar - Fresh Non-Veg Delivered'); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('frontend.components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<main class="home-content">

    
    <section class="hero-section">

        <div class="hero">

            <div class="hero-content">

                <span class="hero-badge">
                    Fresh Everyday
                </span>

                <h1>
                    Fresh Non-Veg.<br>
                    Delivered Fast.
                </h1>

                <p>
                    Premium quality chicken, fish, mutton
                    and seafood at your doorstep.
                </p>

                <form action="<?php echo e(route('payment.razorpay.create')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="hero-btn">
                    Shop Now
                    <span>→</span>
                </button>
                </form>

            </div>

        </div>

    </section>


    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="section">

        <div class="section-header">

            <h2 class="section-title">
                Shop by <?php echo e($category->name); ?>

            </h2>

            <a href="<?php echo e(url($category->slug)); ?>" class="view-all">
                View All
            </a>

        </div>


        <div class="categories">

            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(url($category->slug . '/' . $subcategory->slug)); ?>" class="category">

                <div class="category-image">

                    <img
                        src="<?php echo e($subcategory->image); ?>"
                        alt="Chicken">

                </div>

                <span class="category-name">
                    <?php echo e($subcategory->name); ?>

                </span>

            </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
    <section class="section">

        <div class="offer-card">

            <div class="offer-content">

                <span class="offer-small">
                    WEEKEND SPECIAL
                </span>

                <h2 class="offer-title">
                    Get 20% OFF
                </h2>

                <p class="offer-desc">
                    On your first non-veg order
                </p>

                <a href="#" class="offer-btn">
                    ORDER NOW
                </a>

            </div>

            <div class="offer-image">

                <img
                    src="https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=400&q=80"
                    alt="Special Offer">

            </div>

        </div>

    </section>


    
    <section class="section">

        <div class="section-header">

            <h2 class="section-title">
                Best Sellers
                <span class="fire-icon">🔥</span>
            </h2>

            <!-- <a href="#" class="view-all">
                See All
            </a> -->

        </div>


        <div class="products">

            
            <?php $__currentLoopData = $popularProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article
                class="product-card"
                data-product-id="<?php echo e($product->id); ?>"
                data-name="<?php echo e($product->name); ?>"
                data-category="<?php echo e($product->subcategory_id); ?>"
                data-unit="<?php echo e($product->unit); ?>"
                data-price="<?php echo e($product->price); ?>"
                data-discount-price="<?php echo e($product->discount_price); ?>"
                data-min-qty="<?php echo e($product->minimum_order_qty); ?>"
                data-image="<?php echo e(!empty($product->images) ? asset($product->images[0]) : ''); ?>">

                <div class=" product-image">

                    <?php if(!empty($product->images) && count($product->images) > 0): ?>
                    <img
                        src="<?php echo e(asset($product->images[0])); ?>"
                        alt="<?php echo e($product->name); ?>">
                    <?php endif; ?>

                    <?php if($product->price > $product->discount_price): ?>
                    <?php
                    $discount = round(
                    (($product->price - $product->discount_price) / $product->price) * 100
                    );
                    ?>

                    <span class="discount">
                        <?php echo e($discount); ?>% OFF
                    </span>
                    <?php endif; ?>

                    <!-- <button type="button" class="heart">
                        ♡
                    </button> -->

                </div>

                <div class="product-info">

                    <h3 class="product-name">
                        <?php echo e($product->name); ?>

                    </h3>

                    <p class="product-weight">
                        Minimum <?php echo e($product->minimum_order_qty); ?> <?php echo e($product->unit); ?>

                    </p>

                    <div class="product-rating">
                        ★ 4.8
                        <span>(124)</span>
                    </div>

                    <div class="product-bottom">

                        <div class="product-price">

                            <span class="price">
                                ₹<?php echo e(number_format($product->discount_price, 0)); ?>

                            </span>

                            <?php if($product->price > $product->discount_price): ?>
                            <span class="old-price">
                                ₹<?php echo e(number_format($product->price, 0)); ?>

                            </span>
                            <?php endif; ?>

                        </div>


                        <div class="product-action">

                            <button
                                type="button"
                                class="add-btn"
                                onclick="openQuantityModal(this)">
                                +
                            </button>

                        </div>

                    </div>

                </div>

            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </section>


    
    <section class="section">

        <div class="section-header">

            <h2 class="section-title">
                Why Nonveg Mart?
            </h2>

        </div>


        <div class="features">

            <div class="feature">

                <div class="feature-icon">
                    🥩
                </div>

                <h3 class="feature-title">
                    Fresh Meat
                </h3>

                <p class="feature-text">
                    Freshly prepared
                </p>

            </div>


            <div class="feature">

                <div class="feature-icon">
                    🚚
                </div>

                <h3 class="feature-title">
                    Fast Delivery
                </h3>

                <p class="feature-text">
                    Within your area
                </p>

            </div>


            <div class="feature">

                <div class="feature-icon">
                    🛡️
                </div>

                <h3 class="feature-title">
                    Hygienic
                </h3>

                <p class="feature-text">
                    Safe & clean
                </p>

            </div>

        </div>

    </section>

</main>



<?php echo $__env->make('frontend.components.bottom-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>