

<?php $__env->startSection('title', 'Chicken - Nonveg Bazar'); ?>

<?php $__env->startSection('content'); ?>

<style>
    /* =====================================================
   PRODUCT AVAILABILITY
===================================================== */

    .product-image {
        position: relative;
    }


    /* =====================================================
   UNAVAILABLE PRODUCT
===================================================== */

    .product-unavailable .product-image img {
        filter: grayscale(25%);
        opacity: 0.55;
    }


    /* =====================================================
   STATUS BADGE
===================================================== */

    .product-status {
        position: absolute;

        left: 10px;
        bottom: 10px;

        padding: 6px 10px;

        border-radius: 8px;

        font-size: 10px;
        font-weight: 800;

        letter-spacing: 0.3px;

        color: #ffffff;

        z-index: 2;
    }


    /* SOLD OUT */

    .status-2 {
        background: #555555;
    }


    /* NOT AVAILABLE */

    .status-3 {
        background: #d9534f;
    }


    /* COMING SOON */

    .status-4 {
        background: #f47c20;
    }


    /* =====================================================
   UNAVAILABLE ADD BUTTON
===================================================== */

    .unavailable-btn {
        border: 0;

        background: #eeeeee;

        color: #999999;

        min-height: 34px;

        padding: 0 10px;

        border-radius: 9px;

        font-size: 9px;

        font-weight: 800;

        cursor: not-allowed;

        white-space: nowrap;
    }


    /* =====================================================
   DISABLE HEART
===================================================== */

    .product-unavailable .heart {
        opacity: 0.5;

        cursor: not-allowed;
    }
</style>

<!-- // FIXED PAGE HEADER -->
<header class="page-header">

    <a href="<?php echo e(url($category->slug)); ?>" class="back-btn">
        ←
    </a>

    <div class="page-header-title">

        <h1>
            <?php echo e($subcategory->name); ?>

        </h1>

        <span>
            Fresh & hygienic
        </span>

    </div>

    <a href="#" class="header-btn page-cart-btn">
        🛒

        <span class="cart-count" id="headerCartCount">0</span>
    </a>

</header>


<!-- // FILTER / SORT BAR -->
<!-- <div class="product-filter-wrapper">

        <div class="product-search">

            <span>
                ⌕
            </span>

            <input
                type="search"
                id="productSearch"
                placeholder="Search products..."
                autocomplete="off">

        </div>


        <div class="filter-row">

            <button
                type="button"
                class="filter-btn active"
                data-filter="all">

                All

            </button>


            <button
                type="button"
                class="filter-btn"
                data-filter="chicken">

                Chicken

            </button>


            <button
                type="button"
                class="filter-btn"
                data-filter="combo">

                Combos

            </button>


            <button
                type="button"
                class="filter-btn">

                ⚙ Filter

            </button>

        </div>

    </div> -->


<!-- // PRODUCT PAGE -->
<main class="product-page">


    
    <div class="product-page-heading">

        <div>

            <span class="product-page-label">
                FRESH TODAY
            </span>

            <h2>
                <?php echo e($subcategory->name); ?>

            </h2>

        </div>


        <button
            type="button"
            class="sort-btn">

            Sort
            <span>↓</span>

        </button>

    </div>

    <!-- PRODUCTS -->

    <section class="products product-list">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $status = $product->availability_status ?? 1;

            $statusText = match ($status) {
                2 => 'SOLD OUT',
                3 => 'NOT AVAILABLE',
                4 => 'COMING SOON',
                default => 'AVAILABLE',
            };

            $isAvailable = $status === 1;
        ?>


        <article
            class="product-card <?php echo e(!$isAvailable ? 'product-unavailable' : ''); ?>"

            data-product-id="<?php echo e($product->id); ?>"
            data-name="<?php echo e($product->name); ?>"
            data-category="<?php echo e($product->subcategory_id); ?>"
            data-unit="<?php echo e($product->unit); ?>"
            data-price="<?php echo e($product->price); ?>"
            data-discount-price="<?php echo e($product->discount_price); ?>"
            data-min-qty="<?php echo e($product->minimum_order_qty); ?>"
            data-image="<?php echo e(!empty($product->images) ? asset($product->images[0]) : ''); ?>"
            data-status="<?php echo e($status); ?>">


            <div class="product-image">

                <?php if(!empty($product->images) && count($product->images) > 0): ?>

                <img
                    src="<?php echo e(asset($product->images[0])); ?>"
                    alt="<?php echo e($product->name); ?>">

                <?php endif; ?>


                
                <?php if(!$isAvailable): ?>

                <span class="product-status status-<?php echo e($status); ?>">
                    <?php echo e($statusText); ?>

                </span>

                <?php elseif($product->price > $product->discount_price): ?>

                <?php
                $discount = round(
                (($product->price - $product->discount_price)
                / $product->price) * 100
                );
                ?>

                <span class="discount">
                    <?php echo e($discount); ?>% OFF
                </span>

                <?php endif; ?>


                
                <button
                    type="button"
                    class="heart"
                    <?php echo e(!$isAvailable ? 'disabled' : ''); ?>>

                    ♡

                </button>

            </div>


            <div class="product-info">

                <h3 class="product-name">
                    <?php echo e($product->name); ?>

                </h3>


                <p class="product-weight">
                    Minimum
                    <?php echo e($product->minimum_order_qty); ?>

                    <?php echo e($product->unit); ?>

                </p>


                <div class="product-rating">

                    ★ 4.8

                    <span>
                        (124)
                    </span>

                </div>


                <div class="product-bottom">

                    <div class="product-price">

                        <span class="price">
                            ₹<?php echo e(number_format($product->discount_price, 0)); ?>

                        </span>


                        <?php if($product->price > $product->discount_price): ?>

                        <span class="old-price">
                            ₹<?php echo e(number_format($product->price, 0)); ?>

                        </span>

                        <?php endif; ?>

                    </div>


                    <div class="product-action">

                        <?php if($isAvailable): ?>

                        <button
                            type="button"
                            class="add-btn"
                            onclick="openQuantityModal(this)">

                            +

                        </button>

                        <?php else: ?>

                        <button
                            type="button"
                            class="unavailable-btn"
                            disabled>

                            <?php echo e($statusText); ?>


                        </button>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </article>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>


    <!-- NO RESULT -->
    <div
        id="noProducts"
        class="no-products"
        style="<?php echo e($products->count() > 0 ? 'display:none;' : 'display:block;'); ?>">

        <div class="no-products-icon">
            🔍
        </div>

        <h3>
            No products found
        </h3>

        <p>
            Try searching with another name.
        </p>

    </div>
</main>




<?php echo $__env->make('frontend.components.bottom-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\frontend\pages\products.blade.php ENDPATH**/ ?>