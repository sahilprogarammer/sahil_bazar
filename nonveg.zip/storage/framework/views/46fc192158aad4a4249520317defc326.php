

<?php $__env->startSection('title', 'Categories - Nonveg Bazar'); ?>

<?php $__env->startSection('content'); ?>


<header class="page-header">

    <a href="<?php echo e(route('home')); ?>" class="back-btn">
        ←
    </a>

    <div class="page-header-title">
        <h1><?php echo e($category->name); ?></h1>
        <span>Fresh <?php echo e($category->name); ?> for every meal</span>
    </div>

    <button type="button" class="header-btn page-cart-btn">
        🛒
        <span class="cart-count" id="headerCartCount">0
        </span>
    </button>

</header>



<!-- <div class="category-search-wrapper">

        <div class="category-search">

            <span class="search-icon">
                ⌕
            </span>

            <input
                type="search"
                id="categorySearch"
                placeholder="Search categories..."
                autocomplete="off">

        </div>

    </div> -->



<main class="category-page">

    <div class="category-page-intro">

        <span class="category-page-label">
            EXPLORE
        </span>

        <h2>
            What are you looking for?
        </h2>

        <p>
            Choose your favourite category and discover fresh products.
        </p>

    </div>


    
    <section class="all-categories">

        <?php $__empty_1 = true; $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <a
            href="<?php echo e(url($category->slug . '/' . $subcat->slug)); ?>"
            class="category-circle-card">


            

            <div class="category-circle-image">

                <img
                    src="<?php echo e($subcat->image); ?>"
                    alt="<?php echo e($subcat->name); ?>"
                    loading="lazy">


            </div>



            

            <div class="category-circle-content">

                <h3>
                    <?php echo e($subcat->name); ?>

                </h3>


                <p>
                    Fresh & cleaned
                </p>


                <!-- <span class="category-circle-arrow">
                    →
                </span> -->

            </div>

        </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div class="category-empty">

            <div class="category-empty-icon">
                🥩
            </div>

            <strong>
                No categories available
            </strong>

            <p>
                New categories will appear here soon.
            </p>

        </div>

        <?php endif; ?>

    </section>


    
    <!-- <section class="category-banner">

        <div class="category-banner-content">

            <span>
                TODAY'S SPECIAL
            </span>

            <h2>
                Fresh cuts.<br>
                Better taste.
            </h2>

            <p>
                Quality meat prepared just
                the way you like it.
            </p>

            <a href="#" class="category-banner-btn">
                Explore Deals →
            </a>

        </div>

        <div class="category-banner-image">

            <img
                src="https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=500&q=85"
                alt="Fresh meat">

        </div>

    </section> -->

</main>



<?php echo $__env->make('frontend.components.bottom-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<script>
    const searchInput =
        document.getElementById('categorySearch');

    const categories =
        document.querySelectorAll('.category-large-card');


    // searchInput.addEventListener('input', function() {

    //     const search =
    //         this.value.toLowerCase().trim();


    //     categories.forEach(function(category) {

    //         const name =
    //             category
    //             .querySelector('h3')
    //             .textContent
    //             .toLowerCase();


    //         if (name.includes(search)) {

    //             category.style.display = '';

    //         } else {

    //             category.style.display = 'none';

    //         }

    //     });

    // });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\frontend\pages\categories.blade.php ENDPATH**/ ?>