

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">


    <!-- =========================================
     PAGE HEADER
========================================== -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <div class="page-title">
                Products
            </div>

            <div class="page-subtitle">
                Manage products and their status
            </div>

        </div>


        <!-- Add Product -->

        <a href="<?php echo e(route('product.step1')); ?>"
            class="add-btn"
            title="Add Product">

            <i class="bi bi-plus-lg"></i>

        </a>

    </div>


    <!-- =========================================
     PRODUCT TABLE CARD
========================================== -->

    <div class="premium-card">

        <!-- Card Header -->

        <div class="card-header-custom">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <strong>
                        All Products
                    </strong>

                    <div class="page-subtitle">

                        <?php echo e($products->total()); ?> Products

                    </div>

                </div>

            </div>

        </div>


        <!-- =========================================
         TABLE
    ========================================== -->

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>

                        <th>
                            Product
                        </th>

                        <th>
                            Category
                        </th>

                        <th>
                            Subcategory
                        </th>

                        <th>
                            Type
                        </th>

                        <th>
                            Price
                        </th>

                        <th>
                            Unit
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Created
                        </th>

                        <th class="text-end">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <!-- Product -->

                        <td>

                            <div class="d-flex align-items-center gap-2">

                                <?php
                                $images = $product->images ?? [];

                                if (is_string($images)) {
                                $images = json_decode($images, true) ?? [];
                                }
                                ?>


                                <?php if(!empty($images)): ?>

                                <img
                                    src="<?php echo e(asset($images[0])); ?>"
                                    alt="<?php echo e($product->name); ?>"
                                    width="50"
                                    height="50"
                                    style="object-fit: cover; border-radius: 8px;">

                                <?php else: ?>

                                <div
                                    style="width:50px; height:50px; background:#f3f4f6; border-radius:8px; display:flex; align-items:center; justify-content:center;">

                                    <i class="bi bi-image text-muted"></i>

                                </div>

                                <?php endif; ?>


                                <div>

                                    <div class="fw-semibold">

                                        <?php echo e($product->name); ?>


                                    </div>

                                    <small class="text-muted">

                                        <?php echo e($product->slug); ?>


                                    </small>

                                </div>

                            </div>

                        </td>


                        <!-- Category -->

                        <td>

                            <?php echo e($product->category->name ?? '-'); ?>


                        </td>


                        <!-- Subcategory -->

                        <td>

                            <?php echo e($product->subcategory->name ?? '-'); ?>


                        </td>


                        <!-- Type -->

                        <td>

                            <?php if($product->type === 'veg'): ?>

                            <span class="badge bg-success">
                                Veg
                            </span>

                            <?php else: ?>

                            <span class="badge bg-danger">
                                Non-Veg
                            </span>

                            <?php endif; ?>

                        </td>


                        <!-- Price -->

                        <td>

                            <?php if($product->discount_price): ?>

                            <strong>
                                ₹<?php echo e(number_format($product->discount_price, 2)); ?>

                            </strong>

                            <small class="text-muted text-decoration-line-through">

                                ₹<?php echo e(number_format($product->price, 2)); ?>


                            </small>

                            <?php else: ?>

                            <strong>
                                ₹<?php echo e(number_format($product->price, 2)); ?>

                            </strong>

                            <?php endif; ?>

                        </td>


                        <!-- Stock -->

                        <td>

                            <?php echo e($product->stock); ?>


                            <?php echo e(strtoupper($product->unit)); ?>


                        </td>


                        <!-- Status -->

                        <td>

                            <form
                                action="<?php echo e(route('product.toggleStatus', $product->id)); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>

                                <?php if($product->status === 'active'): ?>

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-success">
                                    <i class="bi bi-check-circle me-1"></i>
                                    Active
                                </button>

                                <?php else: ?>

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-secondary">
                                    <i class="bi bi-x-circle me-1"></i>
                                    Inactive
                                </button>

                                <?php endif; ?>

                            </form>

                        </td>


                        <!-- Created -->

                        <td>

                            <?php echo e($product->created_at->format('d M Y')); ?>


                        </td>


                        <!-- Actions -->

                        <td class="text-end">

                            <div class="d-flex justify-content-end gap-2">

                                

                                <div class="dropdown">

                                    <button
                                        type="button"
                                        class="btn btn-sm"
                                        data-bs-toggle="dropdown"
                                        aria-expanded="false"
                                        title="Edit Product">

                                        <i class="bi bi-pencil"></i>

                                    </button>

                                    <ul class="dropdown-menu dropdown-menu-end">

                                        <li>
                                            <a
                                                class="dropdown-item"
                                                href="<?php echo e(route('product.step1', ['id' => $product->id])); ?>">

                                                <i class="bi bi-info-circle me-2"></i>
                                                Basic Information

                                            </a>
                                        </li>

                                        <li>
                                            <a
                                                class="dropdown-item"
                                                href="<?php echo e(route('product.step2', ['id' => $product->id])); ?>">

                                                <i class="bi bi-currency-rupee me-2"></i>
                                                Pricing & Stock

                                            </a>
                                        </li>

                                        <li>
                                            <a
                                                class="dropdown-item"
                                                href="<?php echo e(route('product.step3', ['id' => $product->id])); ?>">

                                                <i class="bi bi-images me-2"></i>
                                                Media & Description

                                            </a>
                                        </li>

                                    </ul>

                                </div>


                                

                                <a
                                    href="<?php echo e(route('product.step4', ['id' => $product->id])); ?>"
                                    title="View Product">

                                    <i class="bi bi-eye"></i>

                                </a>


                                

                                <!-- <form
                                    action="<?php echo e(route('product.delete', ['id' => $product->id])); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Are you sure you want to delete this product?');">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button
                                        type="submit"
                                        title="Delete Product"
                                        class="border-0 bg-transparent p-0">

                                        <i class="bi bi-trash text-danger"></i>

                                    </button>

                                </form> -->

                            </div>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="9" class="text-center py-5">

                            <i class="bi bi-box-seam fs-1 text-muted"></i>

                            <div class="mt-2 text-muted">

                                No products found.

                            </div>

                        </td>

                    </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        <!-- =========================================
         PAGINATION
    ========================================== -->

        <?php if($products->hasPages()): ?>

        <div class="p-3">

            <?php echo e($products->links()); ?>


        </div>

        <?php endif; ?>

    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\admin\pages\product.blade.php ENDPATH**/ ?>