

<?php $__env->startSection('title', 'My Cart - Nonveg Bazar'); ?>

<?php $__env->startSection('content'); ?>


<header class="page-header">

    <a href="<?php echo e(route('home')); ?>" class="back-btn">
        ←
    </a>

    <div class="page-header-title">

        <h1>My Cart</h1>

        <span>
            Freshness packed for you
        </span>

    </div>

    <div class="cart-header-icon">
    </div>

</header>



<main class="cart-page">

    
    <div class="delivery-card">

        <div class="delivery-icon">
            🚴
        </div>

        <div class="delivery-info">

            <strong>
                Delivery in 30–45 mins
            </strong>

            <span>
                Freshly packed & delivered to you
            </span>

        </div>

        <span class="delivery-arrow">
            →
        </span>

    </div>


    
    <div class="cart-section-heading">

        <div>

            <span>
                YOUR ORDER
            </span>

            <h2 id="cartItemCount">
                0 Items
            </h2>

        </div>

        <button
            type="button"
            class="clear-cart-btn">

            Clear All

        </button>

    </div>


    
    <section
        class="cart-items"
        id="cartItems">

    </section>


    
    <div
        id="emptyCart"
        class="empty-cart"
        style="display: none;">

        <div class="empty-cart-icon">
            🛒
        </div>

        <h3>
            Your cart is empty
        </h3>

        <p>
            Add some fresh products to your cart.
        </p>

        <a
            href="<?php echo e(route('home')); ?>"
            class="empty-cart-btn">

            Start Shopping

        </a>

    </div>


    
    <section class="coupon-card">

        <div class="coupon-icon">
            %
        </div>

        <div class="coupon-info">

            <strong>
                Apply Coupon
            </strong>

            <span>
                Save more on your order
            </span>

        </div>

        <button
            type="button"
            class="coupon-btn">

            Apply

        </button>

    </section>


    
    <section class="bill-card">

        <h3>
            Bill Details
        </h3>


        <div class="bill-row">

            <span>
                Item Total
            </span>

            <strong id="itemTotal">
                ₹0
            </strong>

        </div>


        <div class="bill-row">

            <span>
                Delivery Fee
            </span>

            <strong id="deliveryFee">
                ₹0
            </strong>

        </div>


        <div class="bill-row savings">

            <span>
                Savings
            </span>

            <strong id="savingsAmount">
                - ₹0
            </strong>

        </div>


        <div class="bill-divider"></div>


        <div class="bill-total">

            <span>
                To Pay
            </span>

            <strong id="grandTotal">
                ₹0
            </strong>

        </div>

    </section>


    
    <section class="address-card">

        <div class="address-icon">
            📍
        </div>

        <div class="address-info">

            <?php if(isset($defaultAddress) && $defaultAddress): ?>

            <span>
                DELIVERING TO
            </span>

            <strong>
                <?php echo e(ucfirst($defaultAddress->address_type)); ?>

            </strong>

            <p>
                <?php echo e($defaultAddress->full_address); ?>

            </p>

            <?php else: ?>

            <span>
                DELIVERY ADDRESS
            </span>

            <strong>
                No Address Selected
            </strong>

            <p>
                Add your delivery address
            </p>

            <?php endif; ?>

        </div>

        <button
            type="button"
            onclick="openAddressSelector()"
            class="change-address">

            <?php echo e(isset($defaultAddress) && $defaultAddress ? 'Change' : 'Add'); ?>


        </button>

    </section>

</main>



<div class="checkout-bar">

    <div class="checkout-total">

        <span>
            Total
        </span>

        <strong id="bottomTotal">
            ₹0
        </strong>

    </div>

    <div class="checkout-btn" id="checkoutBtn">

        <form
            method="POST"
            action="<?php echo e(route('checkout')); ?>"
            id="checkoutForm">

            <?php echo csrf_field(); ?>

            <input
                type="hidden"
                name="address_id"
                id="selectedAddressId"
                value="<?php echo e($defaultAddress->id ?? ''); ?>">

            <input
                type="hidden"
                name="cart"
                id="checkoutCart">

            <button
                type="submit"
                class="checkout-button">

                Proceed to Checkout

            </button>

        </form>

    </div>

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    const deliveryChargeRules = <?php echo json_encode($deliveryCharges, 15, 512) ?>;
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {


        /* =====================================================
           CART STORAGE
        ====================================================== */

        function getCart() {

            try {

                const cart =
                    JSON.parse(
                        localStorage.getItem('cart')
                    );

                return Array.isArray(cart) ?
                    cart : [];

            } catch (error) {

                console.error(
                    'Cart localStorage error:',
                    error
                );

                return [];

            }

        }


        function saveCart(cart) {

            localStorage.setItem(
                'cart',
                JSON.stringify(cart)
            );

        }


        /* =====================================================
           FORMAT NUMBER
        ====================================================== */

        function formatNumber(number) {

            number =
                Number(number) || 0;

            return Number.isInteger(number) ?
                number :
                parseFloat(
                    number.toFixed(2)
                );

        }


        /* =====================================================
           FORMAT PRICE
        ====================================================== */

        function formatPrice(price) {

            price =
                Number(price) || 0;

            return '₹' + price.toFixed(2);

        }


        /* =====================================================
           GET SELLING PRICE
        ====================================================== */

        function getSellingPrice(item) {

            return (
                parseFloat(item.selling_price) ||
                parseFloat(item.discount_price) ||
                parseFloat(item.price) ||
                0
            );

        }


        /* =====================================================
           GET UNIT
        ====================================================== */

        function getUnit(item) {

            return String(
                item.unit || 'gram'
            ).toLowerCase();

        }


        /* =====================================================
           GET MINIMUM QUANTITY
        ====================================================== */

        function getMinimumQuantity(item) {

            return (
                parseFloat(
                    item.minimum_order_qty
                ) ||
                parseFloat(
                    item.minQty
                ) ||
                0
            );

        }


        /* =====================================================
           GET QUANTITY STEP
        ====================================================== */

        function getQuantityStep(item) {

            const unit =
                getUnit(item);


            /*
             * Gram
             *
             * 300
             * 350
             * 400
             */

            if (unit === 'gram') {

                return 50;

            }


            /*
             * Liter
             *
             * 1
             * 1.1
             * 1.2
             */

            if (unit === 'liter') {

                return 0.1;

            }


            /*
             * Piece
             * KG
             * Packet
             */

            return 1;

        }


        /* =====================================================
           CALCULATE PRODUCT PRICE
        ====================================================== */

        function calculateItemPrice(item) {

            const quantity =
                parseFloat(item.quantity) || 0;


            const sellingPrice =
                getSellingPrice(item);


            const unit =
                getUnit(item);


            /* =================================================
               GRAM

               Example:

               300 gram
               ₹750/kg

               300 / 1000 × 750

               = ₹225
            ================================================= */

            if (unit === 'gram') {

                return (
                    quantity / 1000
                ) * sellingPrice;

            }


            /* =================================================
               KG

               Example:

               2 kg
               ₹800/kg

               = ₹1600
            ================================================= */

            if (unit === 'kg') {

                return (
                    quantity *
                    sellingPrice
                );

            }


            /* =================================================
               PIECE

               Example:

               5 pieces = ₹300

               1 piece = ₹60

               3 pieces = ₹180
            ================================================= */

            if (unit === 'piece') {

                const pieceQty =
                    parseFloat(
                        item.piece_qty
                    ) || 1;


                const pricePerPiece =
                    sellingPrice /
                    pieceQty;


                return (
                    quantity *
                    pricePerPiece
                );

            }


            /* =================================================
               PACKET

               Price is per packet
            ================================================= */

            if (unit === 'packet') {

                return (
                    quantity *
                    sellingPrice
                );

            }


            /* =================================================
               LITER

               Price is per liter
            ================================================= */

            if (unit === 'liter') {

                return (
                    quantity *
                    sellingPrice
                );

            }


            /* =================================================
               FALLBACK
            ================================================= */

            return (
                quantity *
                sellingPrice
            );

        }


        /* =====================================================
           ESCAPE HTML
        ====================================================== */

        function escapeHtml(value) {

            const div =
                document.createElement(
                    'div'
                );

            div.textContent =
                value == null ?
                '' :
                value;

            return div.innerHTML;

        }


        /* =====================================================
           RENDER CART
        ====================================================== */

        function renderCart() {

            const cart =
                getCart();


            const cartItems =
                document.getElementById(
                    'cartItems'
                );


            const emptyCart =
                document.getElementById(
                    'emptyCart'
                );


            if (!cartItems) {

                return;

            }


            /*
             * Clear old HTML
             */

            cartItems.innerHTML = '';


            /*
             * Empty cart
             */

            if (cart.length === 0) {

                cartItems.style.display =
                    'none';


                if (emptyCart) {

                    emptyCart.style.display =
                        'block';

                }


                updateCartTotal();

                return;

            }


            /*
             * Show cart
             */

            cartItems.style.display =
                'block';


            if (emptyCart) {

                emptyCart.style.display =
                    'none';

            }


            /*
             * Render every product
             */

            cart.forEach(function(
                item,
                index
            ) {


                const quantity =
                    parseFloat(
                        item.quantity
                    ) || 0;


                const unit =
                    getUnit(item);


                const itemTotal =
                    calculateItemPrice(
                        item
                    );


                const image =
                    item.image ||
                    'https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&w=300&q=85';


                const article =
                    document.createElement(
                        'article'
                    );


                article.className =
                    'cart-item';


                article.dataset.index =
                    index;


                article.innerHTML = `

                <div class="cart-product-image">

                    <img
                        src="${escapeHtml(image)}"
                        alt="${escapeHtml(
                            item.name ||
                            'Product'
                        )}">

                </div>


                <div class="cart-product-details">

                    <div class="cart-product-top">

                        <div>

                            <h3>
                                ${escapeHtml(
                                    item.name ||
                                    'Product'
                                )}
                            </h3>

                            <p>
                                ${formatNumber(quantity)}
                                ${escapeHtml(unit)}
                            </p>

                        </div>


                        <button
                            type="button"
                            class="remove-cart-item">

                            ×

                        </button>

                    </div>


                    <div class="cart-product-bottom">

                        <div class="cart-price">

                            ${formatPrice(itemTotal)}

                        </div>


                        <div class="cart-quantity">

                            <button
                                type="button"
                                class="cart-minus">

                                −

                            </button>


                            <span class="cart-qty">

                                ${formatNumber(quantity)}

                            </span>


                            <button
                                type="button"
                                class="cart-plus">

                                +

                            </button>

                        </div>

                    </div>

                </div>

            `;


                cartItems.appendChild(
                    article
                );

            });


            updateCartTotal();

        }


        /* =====================================================
           UPDATE CART TOTAL
        ====================================================== */

        function updateCartTotal() {
            const cart = getCart();
            let itemTotal = 0;
            let itemCount = 0;

            /*
             * Calculate products
             */

            cart.forEach(function(item) {

                itemTotal +=
                    calculateItemPrice(
                        item
                    );

                itemCount++;

            });


            let deliveryFee = 0;

            if (itemCount > 0) {

                const orderAmount = itemTotal;

                /*
                 * For now distance is taken from
                 * selected address.
                 *
                 * If distance is not available,
                 * use 0.
                 */
                const deliveryDistance = getDeliveryDistance();

                const matchingRule = deliveryChargeRules.find(function(rule) {

                    const minDistance =
                        parseFloat(rule.min_distance) || 0;

                    const maxDistance =
                        parseFloat(rule.max_distance) || 0;

                    const minOrderAmount =
                        parseFloat(rule.min_order_amount) || 0;

                    const maxOrderAmount =
                        parseFloat(rule.max_order_amount) || 0;

                    return (
                        deliveryDistance >= minDistance &&
                        deliveryDistance <= maxDistance &&
                        orderAmount >= minOrderAmount &&
                        orderAmount <= maxOrderAmount
                    );

                });

                if (matchingRule) {

                    deliveryFee =
                        parseFloat(
                            matchingRule.charge
                        ) || 0;

                }

            }


            /*
             * Savings
             */
            const savings = 0;

            /*
             * Grand total
             */

            const grandTotal =
                Math.max(
                    itemTotal +
                    deliveryFee -
                    savings,
                    0
                );


            /*
             * Item total
             */

            const itemTotalElement =
                document.getElementById(
                    'itemTotal'
                );


            if (itemTotalElement) {

                itemTotalElement.textContent =
                    formatPrice(
                        itemTotal
                    );

            }


            /*
             * Delivery fee
             */

            const deliveryElement =
                document.getElementById(
                    'deliveryFee'
                );


            if (deliveryElement) {

                deliveryElement.textContent =
                    formatPrice(
                        deliveryFee
                    );

            }


            /*
             * Savings
             */

            const savingsElement =
                document.getElementById(
                    'savingsAmount'
                );


            if (savingsElement) {

                savingsElement.textContent =
                    '- ' +
                    formatPrice(
                        savings
                    );

            }


            /*
             * Grand total
             */

            const grandTotalElement =
                document.getElementById(
                    'grandTotal'
                );


            if (grandTotalElement) {

                grandTotalElement.textContent =
                    formatPrice(
                        grandTotal
                    );

            }


            /*
             * Bottom total
             */

            const bottomTotalElement =
                document.getElementById(
                    'bottomTotal'
                );


            if (bottomTotalElement) {

                bottomTotalElement.textContent =
                    formatPrice(
                        grandTotal
                    );

            }


            /*
             * Item count
             */

            const heading =
                document.getElementById(
                    'cartItemCount'
                );


            if (heading) {

                heading.textContent =
                    itemCount +
                    (
                        itemCount === 1 ?
                        ' Item' :
                        ' Items'
                    );

            }


            /*
             * Global cart count
             */

            if (
                typeof updateCartCount ===
                'function'
            ) {

                updateCartCount();

            }

        }


        /* =====================================================
           PLUS / MINUS / REMOVE
        ====================================================== */

        document.addEventListener(
            'click',
            function(event) {


                /* =================================================
                   PLUS
                ================================================= */

                if (
                    event.target.closest(
                        '.cart-plus'
                    )
                ) {


                    const button =
                        event.target.closest(
                            '.cart-plus'
                        );


                    const cartItem =
                        button.closest(
                            '.cart-item'
                        );


                    if (!cartItem) {

                        return;

                    }


                    const index =
                        parseInt(
                            cartItem.dataset.index,
                            10
                        );


                    let cart =
                        getCart();


                    if (!cart[index]) {

                        return;

                    }


                    const item =
                        cart[index];


                    const minimumQty =
                        getMinimumQuantity(
                            item
                        );


                    const step =
                        getQuantityStep(
                            item
                        );


                    let quantity =
                        parseFloat(
                            item.quantity
                        ) || 0;


                    /*
                     * If old cart data doesn't
                     * have minimum quantity,
                     * use current quantity.
                     */

                    if (
                        minimumQty > 0 &&
                        quantity < minimumQty
                    ) {

                        quantity =
                            minimumQty;

                    } else {

                        quantity +=
                            step;

                    }


                    /*
                     * Format
                     */

                    quantity =
                        formatNumber(
                            quantity
                        );


                    /*
                     * Save
                     */

                    item.quantity =
                        quantity;


                    /*
                     * Recalculate
                     */

                    item.total_price =
                        parseFloat(
                            calculateItemPrice(
                                item
                            ).toFixed(2)
                        );


                    cart[index] =
                        item;


                    saveCart(cart);

                    renderCart();

                    return;

                }


                /* =================================================
                   MINUS
                ================================================= */

                if (
                    event.target.closest(
                        '.cart-minus'
                    )
                ) {


                    const button =
                        event.target.closest(
                            '.cart-minus'
                        );


                    const cartItem =
                        button.closest(
                            '.cart-item'
                        );


                    if (!cartItem) {

                        return;

                    }


                    const index =
                        parseInt(
                            cartItem.dataset.index,
                            10
                        );


                    let cart =
                        getCart();


                    if (!cart[index]) {

                        return;

                    }


                    const item =
                        cart[index];


                    const minimumQty =
                        getMinimumQuantity(
                            item
                        );


                    const step =
                        getQuantityStep(
                            item
                        );


                    let quantity =
                        parseFloat(
                            item.quantity
                        ) || 0;


                    /*
                     * Don't go below minimum
                     */

                    if (
                        minimumQty > 0 &&
                        quantity <= minimumQty
                    ) {

                        item.quantity =
                            minimumQty;

                    } else {

                        let newQuantity =
                            quantity -
                            step;


                        /*
                         * Minimum protection
                         */

                        if (
                            minimumQty > 0 &&
                            newQuantity <
                            minimumQty
                        ) {

                            newQuantity =
                                minimumQty;

                        }


                        item.quantity =
                            formatNumber(
                                newQuantity
                            );

                    }


                    /*
                     * Recalculate
                     */

                    item.total_price =
                        parseFloat(
                            calculateItemPrice(
                                item
                            ).toFixed(2)
                        );


                    cart[index] =
                        item;


                    saveCart(cart);

                    renderCart();

                    return;

                }


                /* =================================================
                   REMOVE ITEM
                ================================================= */

                if (
                    event.target.closest(
                        '.remove-cart-item'
                    )
                ) {


                    const button =
                        event.target.closest(
                            '.remove-cart-item'
                        );


                    const cartItem =
                        button.closest(
                            '.cart-item'
                        );


                    if (!cartItem) {

                        return;

                    }


                    const index =
                        parseInt(
                            cartItem.dataset.index,
                            10
                        );


                    let cart =
                        getCart();


                    if (
                        index >= 0 &&
                        index < cart.length
                    ) {

                        cart.splice(
                            index,
                            1
                        );

                    }


                    saveCart(cart);

                    renderCart();

                    return;

                }

            }
        );


        /* =====================================================
           CLEAR CART
        ====================================================== */

        const clearCartButton =
            document.querySelector(
                '.clear-cart-btn'
            );


        if (clearCartButton) {

            clearCartButton.addEventListener(
                'click',
                function() {


                    const cart =
                        getCart();


                    if (
                        cart.length === 0
                    ) {

                        return;

                    }


                    localStorage.removeItem(
                        'cart'
                    );


                    renderCart();

                }
            );

        }


        /* =====================================================
           CHECKOUT
        ====================================================== */

        const checkoutForm =
            document.getElementById(
                'checkoutForm'
            );


        if (checkoutForm) {

            checkoutForm.addEventListener(
                'submit',
                function(event) {

                    event.preventDefault();


                    const form =
                        this;


                    const cart =
                        getCart();


                    const addressElement =
                        document.getElementById(
                            'selectedAddressId'
                        );


                    const addressId =
                        addressElement ?
                        addressElement.value :
                        '';


                    /*
                     * Cart check
                     */

                    if (
                        cart.length === 0
                    ) {

                        alert(
                            'Your cart is empty.'
                        );

                        return;

                    }


                    /*
                     * Address check
                     */

                    if (!addressId) {

                        alert(
                            'Please select a delivery address.'
                        );


                        if (
                            typeof openAddressSelector ===
                            'function'
                        ) {

                            openAddressSelector();

                        }

                        return;

                    }


                    /*
                     * Set latest cart
                     */

                    const checkoutCart =
                        document.getElementById(
                            'checkoutCart'
                        );


                    checkoutCart.value =
                        JSON.stringify(
                            cart
                        );


                    /*
                     * Form data
                     */

                    const formData =
                        new FormData(
                            form
                        );


                    /*
                     * CSRF
                     */

                    const csrfElement =
                        document.querySelector(
                            'meta[name="csrf-token"]'
                        );


                    const csrfToken =
                        csrfElement ?
                        csrfElement.getAttribute(
                            'content'
                        ) :
                        '';


                    /*
                     * Submit
                     */

                    fetch(
                            form.action, {
                                method: 'POST',

                                body: formData,

                                headers: {

                                    'X-CSRF-TOKEN': csrfToken,

                                    'Accept': 'application/json'

                                }

                            }
                        )
                        .then(function(response) {

                            return response.json();

                        })
                        .then(function(data) {

                            console.log(
                                'Order Response:',
                                data
                            );


                            if (data.success) {

                                /*
                                 * Don't clear cart here
                                 * if checkout/payment page
                                 * still needs it.
                                 */

                                window.location.href =
                                    data.redirect;

                            } else {

                                alert(
                                    data.message ||
                                    'Something went wrong.'
                                );

                            }

                        })
                        .catch(function(error) {

                            console.error(
                                'Checkout Error:',
                                error
                            );


                            alert(
                                'Unable to place order. Please try again.'
                            );

                        });

                }
            );

        }


        /* =====================================================
           INITIAL LOAD
        ====================================================== */

        renderCart();

        function getDeliveryDistance() {

            const distanceElement =
                document.getElementById('deliveryDistance');

            if (distanceElement) {

                return parseFloat(
                    distanceElement.value
                ) || 0;

            }

            return 0;
        }

    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\frontend\pages\cart.blade.php ENDPATH**/ ?>