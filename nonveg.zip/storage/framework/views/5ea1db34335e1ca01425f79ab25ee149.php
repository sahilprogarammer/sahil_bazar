

<?php $__env->startSection('title', 'Delivery Boy Management'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <!-- =========================================
         PAGE HEADER
    ========================================== -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <div class="page-title">
                Delivery Boys
            </div>

            <div class="page-subtitle">
                Manage delivery boys and their status
            </div>
        </div>


        <!-- Add Delivery Boy -->
        <a href="<?php echo e(route('admin.addDeliveryBoy')); ?>"class="add-btn" title="Add Delivery Boy">
            <i class="bi bi-plus-lg"></i>
        </a>

    </div>


    <!-- =========================================
         DELIVERY BOY TABLE CARD
    ========================================== -->

    <div class="premium-card">

        <!-- =========================================
             TABLE
        ========================================== -->

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>

                        <th>
                            Delivery Boy
                        </th>

                        <th>
                            Mobile
                        </th>

                        <th>
                            Vehicle
                        </th>

                        <th>
                            Online
                        </th>

                        <th>
                            Account
                        </th>

                        <th>
                            Created
                        </th>

                        <th class="text-end">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryBoy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        
                        <td>

                            <div class="category-wrapper">

                                
                                <div class="category-image">

                                    <?php if($deliveryBoy->profile_image): ?>

                                    <img
                                        src="<?php echo e(asset($deliveryBoy->profile_image)); ?>"
                                        alt="<?php echo e($deliveryBoy->name); ?>">

                                    <?php else: ?>

                                    <div class="category-placeholder">

                                        <i class="bi bi-person-fill"></i>

                                    </div>

                                    <?php endif; ?>

                                </div>


                                
                                <div>

                                    <div class="category-name">
                                        <?php echo e($deliveryBoy->name); ?>

                                    </div>

                                    <div class="category-id">
                                        #<?php echo e($deliveryBoy->id); ?>

                                    </div>

                                </div>

                            </div>

                        </td>


                        
                        <td>

                            <div>
                                <strong>
                                    <?php echo e($deliveryBoy->mobile); ?>

                                </strong>
                            </div>

                            <?php if($deliveryBoy->email): ?>

                            <small class="text-muted">
                                <?php echo e($deliveryBoy->email); ?>

                            </small>

                            <?php endif; ?>

                        </td>


                        
                        <td>

                            <?php if($deliveryBoy->vehicle_type): ?>

                            <span class="type-badge">

                                <?php if($deliveryBoy->vehicle_type === 'bike'): ?>

                                <i class="bi bi-bicycle"></i>

                                <?php elseif($deliveryBoy->vehicle_type === 'scooter'): ?>

                                <i class="bi bi-scooter"></i>

                                <?php elseif($deliveryBoy->vehicle_type === 'cycle'): ?>

                                <i class="bi bi-bicycle"></i>

                                <?php else: ?>

                                <i class="bi bi-truck"></i>

                                <?php endif; ?>

                                <?php echo e(ucfirst($deliveryBoy->vehicle_type)); ?>


                            </span>

                            <?php else: ?>

                            <span class="text-muted">
                                Not Set
                            </span>

                            <?php endif; ?>


                            <?php if($deliveryBoy->vehicle_number): ?>

                            <div class="mt-1">

                                <small>
                                    <?php echo e(strtoupper($deliveryBoy->vehicle_number)); ?>

                                </small>

                            </div>

                            <?php endif; ?>

                        </td>


                        
                        <td>

                            <?php if($deliveryBoy->is_online): ?>

                            <span class="status status-active">

                                <span class="status-dot"></span>

                                Online

                            </span>

                            <?php else: ?>

                            <span class="status status-inactive">

                                <span class="status-dot"></span>

                                Offline

                            </span>

                            <?php endif; ?>

                        </td>


                        
                        <td>

                            <?php if($deliveryBoy->is_active): ?>

                            <span class="status status-active">

                                <span class="status-dot"></span>

                                Active

                            </span>

                            <?php else: ?>

                            <span class="status status-inactive">

                                <span class="status-dot"></span>

                                Inactive

                            </span>

                            <?php endif; ?>

                        </td>


                        
                        <td>

                            <div class="created-date">

                                <?php echo e($deliveryBoy->created_at?->format('d M Y')); ?>


                            </div>

                            <div class="created-time">

                                <?php echo e($deliveryBoy->created_at?->format('h:i A')); ?>


                            </div>

                        </td>


                        
                        <td>

                            <div class="action-wrapper">

                                
                                <a
                                    href="<?php echo e(route('admin.addDeliveryBoy.edit', $deliveryBoy->id)); ?>"
                                    class="icon-btn edit-btn"
                                    title="Edit">

                                    <i class="bi bi-pencil"></i>

                                </a>


                                
                                <form
                                    action="<?php echo e(route('admin.deliveryboy.delete', $deliveryBoy->id)); ?>"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Are you sure you want to delete this delivery boy?');">

                                    <?php echo csrf_field(); ?>

                                    <?php echo method_field('DELETE'); ?>

                                    <button
                                        type="submit"
                                        class="icon-btn delete-btn"
                                        title="Delete">

                                        <i class="bi bi-trash3"></i>

                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    
                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5">

                            <div class="empty-state">

                                <div class="empty-icon">

                                    <i class="bi bi-person-badge"></i>

                                </div>

                                <h6>
                                    No delivery boys found
                                </h6>

                                <p>
                                    Add your first delivery boy to get started.
                                </p>

                            </div>

                        </td>

                    </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\admin\pages\delivery_boy\deliveryboy.blade.php ENDPATH**/ ?>