

<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">


    <!-- =========================================
         PAGE HEADER
    ========================================== -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h4 class="mb-1">
                Cancel Reports
            </h4>

            <div class="text-muted">
                Manage all customer orders
            </div>

        </div>

    </div>


    <!-- =========================================
         PRODUCT TABLE CARD
    ========================================== -->

    <div class="premium-card">


        <!-- =========================================
             CARD HEADER
        ========================================== -->

        <!-- <div class="card-header-custom">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <strong>
                        All Orders
                    </strong>

                    <div class="page-subtitle">

                        <?php echo e($orders->total()); ?> Orders

                    </div>

                </div>

            </div>

        </div> -->


        <!-- =========================================
             FILTERS
        ========================================== -->

        <div class="p-3 border-bottom">

            <form
                method="post"
                action="<?php echo e(route('admin.report.cancelorder.filter')); ?>">
                <?php echo csrf_field(); ?>

                <div class="row g-3 align-items-end">


                    
                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            From Date
                        </label>

                        <input
                            type="date"
                            name="from_date"
                            class="form-control"
                            value="<?php echo e(request('from_date')); ?>">

                    </div>


                    
                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            To Date
                        </label>

                        <input
                            type="date"
                            name="to_date"
                            class="form-control"
                            value="<?php echo e(request('to_date')); ?>">

                    </div>


                    
                    <div class="col-md-3">

                        <label class="form-label fw-semibold">
                            Order ID
                        </label>

                        <input
                            type="text"
                            name="order_id"
                            class="form-control"
                            placeholder="Search order number..."
                            value="<?php echo e(request('order_id')); ?>">

                    </div>


                    
                    <div class="col-md-3">

                        <div class="d-flex gap-2">

                            <button
                                type="submit"
                                class="btn btn-primary">

                                <i class="bi bi-funnel"></i>

                                Filter

                            </button>


                            <a
                                href="<?php echo e(route('admin.cancelorder')); ?>"
                                class="btn btn-outline-secondary">

                                <i class="bi bi-arrow-clockwise"></i>

                                Reset

                            </a>

                        </div>

                    </div>

                </div>

            </form>

        </div>


        <!-- =========================================
             TABLE
        ========================================== -->

        <div class="table-responsive">

            <table class="table align-middle">


                <!-- TABLE HEADER -->

                <thead>

                    <tr>

                        <th>
                            Order ID
                        </th>

                        <th>
                            Customer / Address
                        </th>

                        <th>
                            Product
                        </th>

                        <th>
                            Price
                        </th>

                        <th>
                            Unit
                        </th>

                        <th>
                            Quantity
                        </th>

                        <th>
                            Total
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Created
                        </th>

                        <!-- <th class="text-end">
                            Actions
                        </th> -->

                    </tr>

                </thead>


                <!-- TABLE BODY -->

                <tbody>


                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


                    <tr>


                        

                        <td>

                            <div class="fw-semibold">

                                #<?php echo e($order->order_number); ?>


                            </div>

                            <small class="text-muted">

                                Order #<?php echo e($order->id); ?>


                            </small>

                        </td>


                        

                        <td style="min-width: 250px;">

                            <?php if($order->address): ?>


                            <div class="fw-semibold">

                                <?php echo e($order->address->name); ?>


                            </div>


                            <small class="text-muted d-block">

                                <i class="bi bi-telephone"></i>

                                <?php echo e($order->address->mobile); ?>


                            </small>


                            <small class="text-muted d-block mt-1">

                                <?php echo e($order->address->full_address); ?>


                            </small>


                            <?php else: ?>


                            <span class="text-muted">

                                Address not available

                            </span>


                            <?php endif; ?>

                        </td>


                        

                        <td>

                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div
                                class="<?php echo e(!$loop->last ? 'mb-2 pb-2 border-bottom' : ''); ?>">

                                <div class="fw-semibold">

                                    <?php echo e($item->product_name); ?>


                                </div>

                            </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>


                        

                        <td>

                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div
                                class="<?php echo e(!$loop->last ? 'mb-2 pb-2 border-bottom' : ''); ?>">

                                <strong>

                                    ₹<?php echo e(number_format($item->selling_price, 2)); ?>


                                </strong>

                            </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>


                        

                        <td>

                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div
                                class="<?php echo e(!$loop->last ? 'mb-2 pb-2 border-bottom' : ''); ?>">

                                <?php echo e(strtoupper($item->unit)); ?>


                            </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>


                        

                        <td>

                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div
                                class="<?php echo e(!$loop->last ? 'mb-2 pb-2 border-bottom' : ''); ?>">

                                <?php echo e(number_format($item->quantity, 2)); ?>


                                <?php echo e(strtoupper($item->unit)); ?>


                            </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>


                        

                        <td>

                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div
                                class="<?php echo e(!$loop->last ? 'mb-2 pb-2 border-bottom' : ''); ?>">

                                <strong>

                                    ₹<?php echo e(number_format($item->total_price, 2)); ?>


                                </strong>

                            </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>


                        

                        <td>


                            <?php if($order->order_status === 'pending'): ?>


                            <span class="badge bg-warning text-dark">

                                Pending

                            </span>


                            <?php elseif($order->order_status === 'confirmed'): ?>


                            <span class="badge bg-primary">

                                Confirmed

                            </span>


                            <?php elseif($order->order_status === 'processing'): ?>


                            <span class="badge bg-info">

                                Processing

                            </span>


                            <?php elseif($order->order_status === 'shipped'): ?>


                            <span class="badge bg-primary">

                                Shipped

                            </span>


                            <?php elseif($order->order_status === 'delivered'): ?>


                            <span class="badge bg-success">

                                Delivered

                            </span>


                            <?php elseif($order->order_status === 'cancelled'): ?>


                            <span class="badge bg-danger">

                                Cancelled

                            </span>


                            <?php else: ?>


                            <span class="badge bg-secondary">

                                <?php echo e(ucfirst($order->order_status ?? 'Unknown')); ?>


                            </span>


                            <?php endif; ?>


                        </td>


                        

                        <td>

                            <?php echo e($order->created_at->format('d M Y')); ?>


                            <br>

                            <small class="text-muted">

                                <?php echo e($order->created_at->format('h:i A')); ?>


                            </small>

                        </td>


                        

                        <!-- <td class="text-end">

                            <a
                                href=""
                                class="btn btn-sm btn-outline-primary">

                                <i class="bi bi-eye"></i>

                                View

                            </a>

                        </td> -->


                    </tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>


                    <!-- =====================================
                         EMPTY STATE
                    ====================================== -->

                    <tr>

                        <td
                            colspan="10"
                            class="text-center py-5">


                            <i
                                class="bi bi-cart-x fs-1 text-muted">
                            </i>


                            <div class="mt-2 text-muted">

                                No orders found.

                            </div>


                            <?php if(
                            request()->filled('from_date') ||
                            request()->filled('to_date') ||
                            request()->filled('order_id') ||
                            request()->filled('status')
                            ): ?>

                            <a
                                href="<?php echo e(url()->current()); ?>"
                                class="btn btn-sm btn-outline-primary mt-3">

                                Clear Filters

                            </a>

                            <?php endif; ?>


                        </td>

                    </tr>


                    <?php endif; ?>


                </tbody>

            </table>

        </div>


        <!-- =========================================
             PAGINATION
        ========================================== -->

        <?php if($orders->hasPages()): ?>

        <div class="p-3">

            <?php echo e($orders->withQueryString()->links()); ?>


        </div>

        <?php endif; ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Nonvegbazar\resources\views\admin\pages\report\cancel_order.blade.php ENDPATH**/ ?>